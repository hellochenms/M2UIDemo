//
//  M2Toast.m
//  M2UIDemo
//
//  Created by Chen Meisong on 13-12-10.
//  Copyright (c) 2013年 Chen Meisong. All rights reserved.
//

#import "M2Toast.h"

@interface M2Toast(){
    UILabel *_textLbl;
}
@end

@implementation M2Toast

- (id)init{
    return [self initWithFrame:CGRectMake(0.0, 0.0, M2T_Width, M2T_Height)];
}

- (id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor colorWithRed:0.0 green:0.0 blue:0.0 alpha:0.618];
        CGRect frame = [UIScreen mainScreen].bounds;
        self.center = CGPointMake(frame.size.width / 2.0, frame.size.height / 3.0);
        
        _textLbl = [[UILabel alloc] initWithFrame:CGRectMake(0.0, 5.0, 200.0, 30.0)];
        _textLbl.backgroundColor = [UIColor clearColor];
        _textLbl.textAlignment = UITextAlignmentCenter;
        _textLbl.font = M2T_Font;
        _textLbl.textColor = [UIColor whiteColor];
        _textLbl.center = CGPointMake(M2T_Width / 2.0, M2T_Height / 2.0);
        [self addSubview:_textLbl];
        
    }
    return self;
}

#pragma mark - private
- (void)showText:(NSString*)text{
    if ([self superview]) {
        return;
    }
    _textLbl.text = text;
    self.alpha = 0;
    [[UIApplication sharedApplication].keyWindow.rootViewController.view addSubview:self];
    __block M2Toast *weakSelf = self;
    [UIView animateWithDuration:0.382
                          delay:0.0
                        options:UIViewAnimationOptionCurveEaseInOut
                     animations:^{
                         weakSelf.alpha = 1.0;
                     }
                     completion:^(BOOL finished) {
                         [weakSelf performSelector:@selector(hide) withObject:nil afterDelay:1];
                     }];
}
- (void)hide{
    __block M2Toast *weakSelf = self;
    [UIView animateWithDuration:0.382
                          delay:0.0
                        options:UIViewAnimationOptionCurveEaseInOut
                     animations:^{
                         weakSelf.alpha = 0.0;
                     }
                     completion:^(BOOL finished) {
                         [weakSelf removeFromSuperview];
                     }];
}

#pragma mark - public
+ (void)showText:(NSString*)text{
    M2Toast *toast = [M2Toast new];
    [toast showText:text];
}

@end
